"""
SmartBus AI — FastAPI Backend (Real ML version)
--------------------------------------------------
Replaces the old hardcoded simulated values (21A -> 5min/90%, etc.)
with live predictions from the trained ETA and Crowd RandomForest models.

Endpoints:
  GET  /                     -> health check
  GET  /routes               -> list of known routes + static info
  POST /predict              -> predict ETA + crowd for ONE bus
  POST /recommend            -> predict for MULTIPLE buses and return
                                 the best recommendation (same contract
                                 your Flutter app already expects)

Run:
  uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
"""

import json
from datetime import datetime
from typing import List, Optional

import joblib
import pandas as pd
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

MODELS_DIR = "/home/claude/smartbus_ai/models"

# ---------------- Load trained artifacts once at startup ----------------
eta_model = joblib.load(f"{MODELS_DIR}/eta_model.joblib")
crowd_model = joblib.load(f"{MODELS_DIR}/crowd_model.joblib")

with open(f"{MODELS_DIR}/feature_schema.json") as f:
    SCHEMA = json.load(f)

with open(f"{MODELS_DIR}/metrics.json") as f:
    METRICS = json.load(f)

BASE_FEATURES = SCHEMA["base_features"]
ROUTE_COLUMNS = SCHEMA["route_columns"]
KNOWN_ROUTES = SCHEMA["routes"]

# Static per-route info the app UI needs (speed/capacity for reference/testing)
ROUTE_INFO = {
    "21A": {"base_speed_kmph": 28, "bus_capacity": 50, "historical_avg_delay": 2.5},
    "21B": {"base_speed_kmph": 24, "bus_capacity": 50, "historical_avg_delay": 4.0},
    "21C": {"base_speed_kmph": 32, "bus_capacity": 45, "historical_avg_delay": 1.0},
    "22A": {"base_speed_kmph": 26, "bus_capacity": 60, "historical_avg_delay": 3.0},
    "22B": {"base_speed_kmph": 22, "bus_capacity": 40, "historical_avg_delay": 5.0},
}

app = FastAPI(title="SmartBus AI", version="1.0.0")

# Allow the Flutter app (web/mobile/emulator) to call this API freely during the demo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------- Request / Response schemas ----------------
class BusInput(BaseModel):
    route_id: str = Field(..., example="21A")
    distance_km: float = Field(..., gt=0, example=3.2)
    traffic_level: Optional[float] = Field(
        None, ge=0, le=1, description="0=clear, 1=gridlock. Auto-estimated if omitted."
    )
    weather: Optional[int] = Field(
        None, ge=0, le=1, description="0=clear, 1=rain. Defaults to 0 if omitted."
    )
    stop_waiting_count: Optional[int] = Field(
        None, ge=0, description="People waiting at the stop right now."
    )
    onboard_count: Optional[int] = Field(
        None, ge=0, description="People currently on the bus."
    )
    timestamp: Optional[str] = Field(
        None, description="ISO datetime. Defaults to server 'now' if omitted."
    )


class PredictionOut(BaseModel):
    route_id: str
    eta_min: float
    crowd_pct: float
    crowd_label: str


class RecommendationOut(BaseModel):
    predictions: List[PredictionOut]
    recommended_route: str
    reason: str


# ---------------- Helper functions ----------------
def _crowd_label(pct: float) -> str:
    if pct < 40:
        return "Low"
    if pct < 70:
        return "Moderate"
    return "High"


def _build_feature_row(bus: BusInput) -> pd.DataFrame:
    route = bus.route_id.upper()
    if route not in ROUTE_INFO:
        # Unknown route: fall back to reasonable city-average defaults
        info = {"base_speed_kmph": 26, "bus_capacity": 50, "historical_avg_delay": 3.0}
    else:
        info = ROUTE_INFO[route]

    ts = datetime.fromisoformat(bus.timestamp) if bus.timestamp else datetime.now()
    hour = ts.hour
    day_of_week = ts.weekday()
    is_weekday = day_of_week < 5
    is_peak_hour = int(is_weekday and (8 <= hour <= 10 or 17 <= hour <= 20))

    traffic_level = bus.traffic_level
    if traffic_level is None:
        traffic_level = 0.65 if is_peak_hour else 0.25  # sensible default estimate

    weather = bus.weather if bus.weather is not None else 0
    stop_waiting_count = bus.stop_waiting_count if bus.stop_waiting_count is not None else 8
    onboard_count = (
        bus.onboard_count
        if bus.onboard_count is not None
        else int(info["bus_capacity"] * (0.6 if is_peak_hour else 0.3))
    )

    row = {
        "distance_km": bus.distance_km,
        "base_speed_kmph": info["base_speed_kmph"],
        "traffic_level": traffic_level,
        "hour": hour,
        "day_of_week": day_of_week,
        "is_peak_hour": is_peak_hour,
        "weather": weather,
        "historical_avg_delay": info["historical_avg_delay"],
        "stop_waiting_count": stop_waiting_count,
        "onboard_count": onboard_count,
        "bus_capacity": info["bus_capacity"],
    }
    for col in ROUTE_COLUMNS:
        row[col] = 1 if col == f"route_{route}" else 0

    ordered_cols = BASE_FEATURES + ROUTE_COLUMNS
    return pd.DataFrame([row])[ordered_cols]


def _predict_one(bus: BusInput) -> PredictionOut:
    X = _build_feature_row(bus)
    eta = float(eta_model.predict(X)[0])
    crowd = float(crowd_model.predict(X)[0])
    crowd = max(0.0, min(100.0, crowd))
    return PredictionOut(
        route_id=bus.route_id.upper(),
        eta_min=round(eta, 1),
        crowd_pct=round(crowd, 1),
        crowd_label=_crowd_label(crowd),
    )


def _score(pred: PredictionOut) -> float:
    """Lower is better. Weighs ETA more heavily than crowd, mirroring the
    original rule-based logic but now driven by real model predictions."""
    return pred.eta_min * 1.0 + (pred.crowd_pct / 100.0) * 4.0


# ---------------- Routes ----------------
@app.get("/")
def health():
    return {
        "status": "ok",
        "service": "SmartBus AI",
        "models_loaded": True,
        "metrics": METRICS,
    }


@app.get("/routes")
def list_routes():
    return {"routes": KNOWN_ROUTES, "info": ROUTE_INFO}


@app.post("/predict", response_model=PredictionOut)
def predict(bus: BusInput):
    """Predict ETA + crowd for a single bus (replaces the old hardcoded values)."""
    return _predict_one(bus)


@app.post("/recommend", response_model=RecommendationOut)
def recommend(buses: List[BusInput]):
    """Predict for multiple candidate buses and recommend the best one."""
    predictions = [_predict_one(b) for b in buses]
    best = min(predictions, key=_score)
    reason = (
        f"{best.route_id} has the best balance of wait time ({best.eta_min} min) "
        f"and crowd level ({best.crowd_pct}% - {best.crowd_label})."
    )
    return RecommendationOut(
        predictions=predictions, recommended_route=best.route_id, reason=reason
    )
