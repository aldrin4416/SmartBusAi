# SmartBus AI — ML Core (the "remaining 65%")

This package builds the parts you flagged as missing: a real dataset, two
trained ML models (ETA + Crowd), a recommendation engine built on their
predictions, and a validation report — replacing your hardcoded
`21A → 5min → 90%` demo values with actual model output.

## What's in here

```
smartbus_ai/
├── data/
│   ├── generate_dataset.py   # builds the synthetic-but-realistic training dataset
│   └── bus_dataset.csv       # 20,000 rows: distance, traffic, time, delay, crowd, etc.
├── models/
│   ├── eta_model.joblib      # trained RandomForestRegressor -> predicts ETA (minutes)
│   ├── crowd_model.joblib    # trained RandomForestRegressor -> predicts crowd (%)
│   ├── feature_schema.json   # feature order/route encoding used by the API
│   └── metrics.json          # accuracy numbers (MAE, R^2)
├── app/
│   └── main.py                # FastAPI backend: /predict and /recommend
├── train_models.py            # trains both models from the dataset
├── validate.py                 # accuracy + latency + demo-scenario report
└── README.md
```

## How the roadmap maps to this package

| Stage | Status |
|---|---|
| Realistic bus dataset | ✅ `data/generate_dataset.py` → `bus_dataset.csv` |
| ETA ML model | ✅ `models/eta_model.joblib` (MAE ≈ 1.3 min, R² ≈ 0.99) |
| Crowd ML model | ✅ `models/crowd_model.joblib` (MAE ≈ 3.3%, R² ≈ 0.96) |
| Recommendation (on real predictions) | ✅ `/recommend` endpoint in `app/main.py` |
| Testing/validation | ✅ `validate.py` — accuracy, latency, scenario tests |
| Database, live map, notifications, final integration | Not built yet — see "Next steps" |

## Why the dataset is synthetic

There's no live GPS/ticketing feed yet, so `generate_dataset.py` simulates
20,000 realistic trips using formulas that mirror how real bus systems behave:
traffic and rain slow buses down, peak hours (8–10am, 5–8pm weekdays) increase
both delay and crowding, and each route has its own historical delay profile.
This is the standard approach for an early-stage ML prototype — it lets you
train and demo real models now, and you swap in live data later without
changing any code downstream (same feature schema).

## Running it

```bash
pip install fastapi uvicorn scikit-learn pandas numpy joblib

# Regenerate dataset (optional — bus_dataset.csv is already included)
python3 data/generate_dataset.py

# Train both models (optional — trained .joblib files are already included)
python3 train_models.py

# Run the validation report (accuracy + latency + demo scenarios)
python3 validate.py

# Start the API server
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## API — what your Flutter app should call

### `POST /predict` — single bus
```json
// Request
{"route_id": "21A", "distance_km": 3.2}

// Response
{"route_id": "21A", "eta_min": 7.7, "crowd_pct": 31.9, "crowd_label": "Low"}
```

### `POST /recommend` — multiple candidate buses (this replaces your old logic)
```json
// Request
[
  {"route_id": "21A", "distance_km": 2.2},
  {"route_id": "21B", "distance_km": 3.5},
  {"route_id": "21C", "distance_km": 6.0}
]

// Response
{
  "predictions": [
    {"route_id": "21A", "eta_min": 7.7, "crowd_pct": 31.9, "crowd_label": "Low"},
    {"route_id": "21B", "eta_min": 12.6, "crowd_pct": 31.4, "crowd_label": "Low"},
    {"route_id": "21C", "eta_min": 14.6, "crowd_pct": 31.2, "crowd_label": "Low"}
  ],
  "recommended_route": "21A",
  "reason": "21A has the best balance of wait time (7.7 min) and crowd level (31.9% - Low)."
}
```

Optional fields you can pass for more realistic predictions: `traffic_level`
(0–1), `weather` (0/1), `stop_waiting_count`, `onboard_count`, `timestamp`
(ISO datetime — used to auto-detect peak hour). Omit any of them and the API
fills in sensible defaults, so your existing Flutter calls keep working with
zero changes on the client side beyond pointing at `/recommend` instead of
your mock data.

## What to say to the judges

- "We moved from a rule-based demo to two trained ML models — RandomForest
  regressors — on a 20,000-row dataset combining GPS distance, traffic,
  weather, time-of-day, and historical delay per route."
- "ETA predictions are accurate to about 1.3 minutes (MAE) and crowd predictions
  to about 3 percentage points on held-out test data, both with R² above 0.96."
- "Inference is ~13ms per request, so recommendations are effectively
  instant in the app."
- "The recommendation engine scores every candidate bus using both predicted
  ETA and predicted crowd, not just ETA alone."

## Next steps (the parts not built yet)

1. **Database** — persist real trip history (Postgres/SQLite) so models can
   be retrained on real data over time, not just the synthetic set.
2. **Live map** — GPS feed (or simulated GPS mover) driving bus positions
   on a Flutter map (`google_maps_flutter` or `flutter_map`).
3. **Notifications** — push alert when a recommended bus is N minutes out
   (Firebase Cloud Messaging works well with Flutter).
4. **Final integration** — wire the Flutter screens you already built to
   call `/recommend` on this backend instead of the simulated dataset.

I can build any of these next — just say which one.
