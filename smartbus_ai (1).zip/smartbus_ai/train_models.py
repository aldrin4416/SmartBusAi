"""
SmartBus AI — Model Training
------------------------------
Trains two RandomForest regression models:
  1. ETA model      -> predicts minutes until bus arrival
  2. Crowd model    -> predicts % capacity (crowd level)

Saves both models + the fitted route encoder to /models so the FastAPI
backend can load them directly for real-time predictions.
"""

import json
import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, r2_score

DATA_PATH = "/home/claude/smartbus_ai/data/bus_dataset.csv"
MODELS_DIR = "/home/claude/smartbus_ai/models"

df = pd.read_csv(DATA_PATH)

# One-hot encode route_id (small fixed set of routes -> simple + robust for demo)
route_dummies = pd.get_dummies(df["route_id"], prefix="route")
route_columns = list(route_dummies.columns)

FEATURES = [
    "distance_km",
    "base_speed_kmph",
    "traffic_level",
    "hour",
    "day_of_week",
    "is_peak_hour",
    "weather",
    "historical_avg_delay",
    "stop_waiting_count",
    "onboard_count",
    "bus_capacity",
] + route_columns

X = pd.concat([df[FEATURES[:-len(route_columns)]], route_dummies], axis=1)

# ---------------- ETA MODEL ----------------
y_eta = df["eta_min"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y_eta, test_size=0.2, random_state=42
)
eta_model = RandomForestRegressor(
    n_estimators=60, max_depth=9, min_samples_leaf=5, random_state=42, n_jobs=-1
)
eta_model.fit(X_train, y_train)
eta_pred = eta_model.predict(X_test)
eta_mae = mean_absolute_error(y_test, eta_pred)
eta_r2 = r2_score(y_test, eta_pred)
print(f"[ETA MODEL]   MAE = {eta_mae:.2f} min   R2 = {eta_r2:.3f}")

# ---------------- CROWD MODEL ----------------
y_crowd = df["crowd_pct"]
X_train2, X_test2, y_train2, y_test2 = train_test_split(
    X, y_crowd, test_size=0.2, random_state=42
)
crowd_model = RandomForestRegressor(
    n_estimators=60, max_depth=9, min_samples_leaf=5, random_state=42, n_jobs=-1
)
crowd_model.fit(X_train2, y_train2)
crowd_pred = crowd_model.predict(X_test2)
crowd_mae = mean_absolute_error(y_test2, crowd_pred)
crowd_r2 = r2_score(y_test2, crowd_pred)
print(f"[CROWD MODEL] MAE = {crowd_mae:.2f} %     R2 = {crowd_r2:.3f}")

# ---------------- SAVE ARTIFACTS ----------------
# compress=3 shrinks file size substantially with negligible load-time cost
joblib.dump(eta_model, f"{MODELS_DIR}/eta_model.joblib", compress=3)
joblib.dump(crowd_model, f"{MODELS_DIR}/crowd_model.joblib", compress=3)

with open(f"{MODELS_DIR}/feature_schema.json", "w") as f:
    json.dump(
        {
            "base_features": FEATURES[: -len(route_columns)],
            "route_columns": route_columns,
            "routes": sorted(df["route_id"].unique().tolist()),
        },
        f,
        indent=2,
    )

with open(f"{MODELS_DIR}/metrics.json", "w") as f:
    json.dump(
        {
            "eta_mae_minutes": round(float(eta_mae), 3),
            "eta_r2": round(float(eta_r2), 3),
            "crowd_mae_percent": round(float(crowd_mae), 3),
            "crowd_r2": round(float(crowd_r2), 3),
            "train_rows": len(X_train),
            "test_rows": len(X_test),
        },
        f,
        indent=2,
    )

print("\nSaved models + schema + metrics to /models")
