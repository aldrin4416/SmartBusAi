"""
SmartBus AI — Synthetic Training Dataset Generator
----------------------------------------------------
Generates a realistic bus-transit dataset for training:
  1. An ETA prediction model (regression -> minutes)
  2. A Crowd prediction model (regression -> % capacity)

Since real GPS/ticketing data isn't available for the demo, we simulate
it using domain-realistic formulas + noise, the same approach used for
early-stage transit ML prototypes before live data collection begins.

Features per row:
  route_id            - bus route (21A, 21B, 21C, 22A, 22B)
  distance_km          - remaining distance from bus to the stop
  base_speed_kmph      - route's normal cruising speed
  traffic_level        - 0 (clear) - 1 (gridlock)
  hour                 - hour of day (0-23)
  day_of_week          - 0=Mon ... 6=Sun
  is_peak_hour         - derived flag (8-10am, 5-8pm on weekdays)
  weather              - 0=clear, 1=rain
  historical_avg_delay - route's historical average delay (minutes)
  stop_waiting_count   - people waiting at the stop
  onboard_count        - people already on the bus
  bus_capacity         - max capacity of the bus

Targets:
  eta_min              - realistic ground-truth ETA (minutes)
  crowd_pct            - realistic ground-truth crowd level (%)
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N = 20000  # rows

ROUTES = {
    # route_id: (base_speed_kmph, capacity, historical_delay_mean)
    "21A": (28, 50, 2.5),
    "21B": (24, 50, 4.0),
    "21C": (32, 45, 1.0),
    "22A": (26, 60, 3.0),
    "22B": (22, 40, 5.0),
}
route_ids = list(ROUTES.keys())

rows = []
for _ in range(N):
    route = np.random.choice(route_ids)
    base_speed, capacity, hist_delay_mean = ROUTES[route]

    distance_km = np.round(np.random.uniform(0.3, 12.0), 2)
    hour = np.random.randint(0, 24)
    day_of_week = np.random.randint(0, 7)
    is_weekday = day_of_week < 5
    is_peak_hour = int(is_weekday and (8 <= hour <= 10 or 17 <= hour <= 20))

    # Traffic tends to be worse during peak hours, random otherwise
    traffic_level = np.clip(
        np.random.beta(5, 2) if is_peak_hour else np.random.beta(2, 4), 0, 1
    )

    weather = np.random.choice([0, 1], p=[0.8, 0.2])  # 20% chance of rain
    historical_avg_delay = np.round(
        np.random.normal(hist_delay_mean, 1.2), 2
    ).clip(0, None)

    stop_waiting_count = int(
        np.clip(np.random.poisson(15 if is_peak_hour else 6), 0, 80)
    )
    onboard_count = int(
        np.clip(
            np.random.poisson(capacity * (0.65 if is_peak_hour else 0.30)),
            0,
            capacity + 15,  # allow slight overcrowding beyond nominal capacity
        )
    )

    # ---- Ground truth ETA formula ----
    # Effective speed drops with traffic and rain; distance/speed gives base time;
    # add historical delay signal and small random noise.
    traffic_slowdown = 1 - (0.65 * traffic_level)          # up to 65% slower
    weather_slowdown = 1 - (0.15 * weather)                 # 15% slower in rain
    effective_speed = max(base_speed * traffic_slowdown * weather_slowdown, 4)

    base_time_min = (distance_km / effective_speed) * 60
    delay_component = historical_avg_delay * (0.5 + 0.5 * traffic_level)
    noise = np.random.normal(0, 1.0)
    eta_min = max(base_time_min + delay_component + noise, 0.5)

    # ---- Ground truth Crowd formula ----
    crowd_base = (onboard_count / capacity) * 100
    peak_bump = 12 if is_peak_hour else 0
    weather_bump = 6 if weather else 0
    waiting_bump = stop_waiting_count * 0.3
    crowd_noise = np.random.normal(0, 4)
    crowd_pct = np.clip(
        crowd_base + peak_bump + weather_bump + waiting_bump + crowd_noise, 0, 100
    )

    rows.append(
        dict(
            route_id=route,
            distance_km=distance_km,
            base_speed_kmph=base_speed,
            traffic_level=round(float(traffic_level), 3),
            hour=hour,
            day_of_week=day_of_week,
            is_peak_hour=is_peak_hour,
            weather=weather,
            historical_avg_delay=historical_avg_delay,
            stop_waiting_count=stop_waiting_count,
            onboard_count=onboard_count,
            bus_capacity=capacity,
            eta_min=round(float(eta_min), 2),
            crowd_pct=round(float(crowd_pct), 2),
        )
    )

df = pd.DataFrame(rows)
out_path = "/home/claude/smartbus_ai/data/bus_dataset.csv"
df.to_csv(out_path, index=False)
print(f"Saved {len(df)} rows to {out_path}")
print(df.head())
print("\nSummary stats:")
print(df[["eta_min", "crowd_pct"]].describe())
