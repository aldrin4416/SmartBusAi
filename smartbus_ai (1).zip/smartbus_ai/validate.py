"""
SmartBus AI — Testing & Validation
------------------------------------
Item #10 on the roadmap: Accuracy + performance validation.

Run this to get a printed report you can literally show judges:
  - Model accuracy (MAE, R^2) on held-out test data
  - Prediction latency (ms per request)
  - A few realistic demo scenarios (peak hour vs. off-peak, rain vs. clear)
"""

import json
import time

from fastapi.testclient import TestClient

from app.main import app, METRICS

client = TestClient(app)

print("=" * 60)
print("SMARTBUS AI — MODEL VALIDATION REPORT")
print("=" * 60)

print("\n[1] Model Accuracy (held-out test set, 4,000 rows)")
print(f"    ETA Model    -> MAE: {METRICS['eta_mae_minutes']} min   |  R^2: {METRICS['eta_r2']}")
print(f"    Crowd Model  -> MAE: {METRICS['crowd_mae_percent']} %    |  R^2: {METRICS['crowd_r2']}")

print("\n[2] Prediction Latency")
payload = {"route_id": "21A", "distance_km": 3.0}
times = []
for _ in range(50):
    t0 = time.perf_counter()
    client.post("/predict", json=payload)
    times.append((time.perf_counter() - t0) * 1000)
print(f"    Avg latency over 50 calls: {sum(times)/len(times):.1f} ms  "
      f"(min {min(times):.1f} ms / max {max(times):.1f} ms)")

print("\n[3] Scenario Tests")

scenarios = {
    "Off-peak, clear weather (10am)": [
        {"route_id": "21A", "distance_km": 3.0, "traffic_level": 0.2, "weather": 0,
         "timestamp": "2026-09-17T11:00:00"},
        {"route_id": "21B", "distance_km": 3.0, "traffic_level": 0.2, "weather": 0,
         "timestamp": "2026-09-17T11:00:00"},
        {"route_id": "21C", "distance_km": 3.0, "traffic_level": 0.2, "weather": 0,
         "timestamp": "2026-09-17T11:00:00"},
    ],
    "Evening peak hour, rain": [
        {"route_id": "21A", "distance_km": 3.0, "traffic_level": 0.85, "weather": 1,
         "timestamp": "2026-09-17T18:00:00"},
        {"route_id": "21B", "distance_km": 3.0, "traffic_level": 0.85, "weather": 1,
         "timestamp": "2026-09-17T18:00:00"},
        {"route_id": "21C", "distance_km": 3.0, "traffic_level": 0.85, "weather": 1,
         "timestamp": "2026-09-17T18:00:00"},
    ],
}

for name, buses in scenarios.items():
    r = client.post("/recommend", json=buses)
    data = r.json()
    print(f"\n  Scenario: {name}")
    for p in data["predictions"]:
        print(f"    {p['route_id']}: ETA {p['eta_min']:>5.1f} min | "
              f"Crowd {p['crowd_pct']:>5.1f}% ({p['crowd_label']})")
    print(f"    -> Recommended: {data['recommended_route']}  "
          f"({data['reason']})")

print("\n" + "=" * 60)
print("Validation complete.")
print("=" * 60)
