import 'package:flutter/material.dart';
import '../models/bus.dart';
import '../services/api_service.dart';
import '../widgets/bus_card.dart';

class NearbyBusesScreen extends StatefulWidget {
  const NearbyBusesScreen({super.key});

  @override
  State<NearbyBusesScreen> createState() => _NearbyBusesScreenState();
}

class _NearbyBusesScreenState extends State<NearbyBusesScreen> {
  final ApiService _api = ApiService();
  Recommendation? _recommendation;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rec = await _api.fetchRecommendation();
      setState(() {
        _recommendation = rec;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = "Couldn't reach the backend.\n$e";
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Nearby Buses"),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_error != null) {
      return ListView(
        children: [
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.wifi_off, size: 42, color: Colors.grey),
                const SizedBox(height: 12),
                Text(_error!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                ElevatedButton(onPressed: _load, child: const Text("Retry")),
                const SizedBox(height: 8),
                const Text(
                  "Tip: Android emulator uses 10.0.2.2 to reach your laptop's "
                  "localhost. Update ApiService.baseUrl for other setups.",
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ],
      );
    }

    final rec = _recommendation!;
    return ListView(
      padding: const EdgeInsets.only(top: 8, bottom: 24),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.blueAccent.withOpacity(0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(Icons.auto_awesome, color: Colors.blueAccent),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    rec.reason,
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
          ),
        ),
        ...rec.buses.map(
          (bus) => BusCard(
            bus: bus,
            isRecommended: bus.busId == rec.recommendedBusId,
          ),
        ),
      ],
    );
  }
}
