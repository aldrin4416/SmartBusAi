import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/bus.dart';

/// Handles the Flutter <-> FastAPI connection.
///
/// Update [baseUrl] to match where your backend is running:
///  - Android emulator talking to your laptop:  http://10.0.2.2:8000
///  - iOS simulator / web / desktop:             http://127.0.0.1:8000
///  - Physical device on same Wi-Fi:             http://<your-laptop-ip>:8000
class ApiService {
  static const String baseUrl = "http://10.0.2.2:8000";

  Future<List<Bus>> fetchNearbyBuses() async {
    final response = await http.get(Uri.parse("$baseUrl/buses"));
    if (response.statusCode != 200) {
      throw Exception("Failed to load buses (${response.statusCode})");
    }
    final List data = jsonDecode(response.body);
    return data.map((b) => Bus.fromJson(b)).toList();
  }

  Future<Recommendation> fetchRecommendation() async {
    final response = await http.get(Uri.parse("$baseUrl/recommend"));
    if (response.statusCode != 200) {
      throw Exception("Failed to load recommendation (${response.statusCode})");
    }
    return Recommendation.fromJson(jsonDecode(response.body));
  }
}
