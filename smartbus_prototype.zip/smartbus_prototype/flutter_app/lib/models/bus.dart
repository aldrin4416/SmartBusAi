class Bus {
  final String busId;
  final String route;
  final int etaMin;
  final int crowdPct;
  final String crowdLabel;

  Bus({
    required this.busId,
    required this.route,
    required this.etaMin,
    required this.crowdPct,
    required this.crowdLabel,
  });

  factory Bus.fromJson(Map<String, dynamic> json) {
    return Bus(
      busId: json['bus_id'] as String,
      route: json['route'] as String,
      etaMin: json['eta_min'] as int,
      crowdPct: json['crowd_pct'] as int,
      crowdLabel: json['crowd_label'] as String,
    );
  }
}

class Recommendation {
  final List<Bus> buses;
  final String recommendedBusId;
  final String reason;

  Recommendation({
    required this.buses,
    required this.recommendedBusId,
    required this.reason,
  });

  factory Recommendation.fromJson(Map<String, dynamic> json) {
    return Recommendation(
      buses: (json['buses'] as List)
          .map((b) => Bus.fromJson(b as Map<String, dynamic>))
          .toList(),
      recommendedBusId: json['recommended_bus_id'] as String,
      reason: json['reason'] as String,
    );
  }
}
