import 'package:flutter/material.dart';

class CrowdIndicator extends StatelessWidget {
  final int crowdPct;
  final String crowdLabel;

  const CrowdIndicator({
    super.key,
    required this.crowdPct,
    required this.crowdLabel,
  });

  Color get _color {
    if (crowdPct < 40) return Colors.green;
    if (crowdPct < 70) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(color: _color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 6),
        Text(
          "$crowdLabel ($crowdPct%)",
          style: TextStyle(color: _color, fontWeight: FontWeight.w600),
        ),
      ],
    );
  }
}
