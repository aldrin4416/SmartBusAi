import 'package:flutter/material.dart';
import '../models/bus.dart';
import 'crowd_indicator.dart';

class BusCard extends StatelessWidget {
  final Bus bus;
  final bool isRecommended;

  const BusCard({super.key, required this.bus, this.isRecommended = false});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: isRecommended ? 4 : 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: isRecommended
            ? const BorderSide(color: Colors.blueAccent, width: 2)
            : BorderSide.none,
      ),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: isRecommended
                  ? Colors.blueAccent
                  : Colors.grey.shade300,
              child: Text(
                bus.route,
                style: TextStyle(
                  color: isRecommended ? Colors.white : Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "Route ${bus.route}",
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                      if (isRecommended) ...[
                        const SizedBox(width: 8),
                        const Icon(Icons.auto_awesome,
                            size: 16, color: Colors.blueAccent),
                        const Text(
                          " AI Pick",
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontWeight: FontWeight.w600,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 4),
                  CrowdIndicator(
                      crowdPct: bus.crowdPct, crowdLabel: bus.crowdLabel),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "${bus.etaMin}",
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const Text("min", style: TextStyle(color: Colors.grey)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
