"""
SmartBus AI — Prototype Backend (the "35%")
-----------------------------------------------
This is the validation-stage backend:
  - Simulated bus data (no ML yet — that's the next 65%)
  - Basic recommendation logic: compares ETA + crowd, picks the better bus

Endpoints:
  GET  /                -> health check
  GET  /buses           -> nearby buses for a route (simulated ETA + crowd)
  GET  /recommend        -> best bus for a route (basic rule-based scoring)

Run:
  uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""

import random
from typing import Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="SmartBus AI — Prototype", version="0.1.0")

# Allow the Flutter app (emulator / web / device) to call this freely during the demo
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class Bus(BaseModel):
    bus_id: str
    route: str
    eta_min: int
    crowd_pct: int
    crowd_label: str


class RecommendationResponse(BaseModel):
    buses: List[Bus]
    recommended_bus_id: str
    reason: str


# ---------------- Simulated dataset ----------------
# Matches your original example: 21A -> 5min/90%, 21B -> 8min/55%, 21C -> 12min/30%
# Small random jitter is added each request so the demo feels "live".
SIMULATED_ROUTES: Dict[str, Dict] = {
    "21A": {"base_eta": 5, "base_crowd": 90},
    "21B": {"base_eta": 8, "base_crowd": 55},
    "21C": {"base_eta": 12, "base_crowd": 30},
}


def _crowd_label(pct: int) -> str:
    if pct < 40:
        return "Low"
    if pct < 70:
        return "Moderate"
    return "High"


def _simulate_buses() -> List[Bus]:
    buses = []
    for route, info in SIMULATED_ROUTES.items():
        eta = max(1, info["base_eta"] + random.randint(-1, 2))
        crowd = max(0, min(100, info["base_crowd"] + random.randint(-5, 5)))
        buses.append(
            Bus(
                bus_id=f"{route}-{random.randint(100, 999)}",
                route=route,
                eta_min=eta,
                crowd_pct=crowd,
                crowd_label=_crowd_label(crowd),
            )
        )
    return buses


def _score(bus: Bus) -> float:
    """Basic AI-style scoring: lower is better.
    Weighs waiting time and crowding together, same logic as your original
    prototype (compares ETA + crowd, picks the better bus overall)."""
    return bus.eta_min * 1.0 + (bus.crowd_pct / 100.0) * 5.0


# ---------------- Routes ----------------
@app.get("/")
def health():
    return {"status": "ok", "service": "SmartBus AI Prototype"}


@app.get("/buses", response_model=List[Bus])
def nearby_buses():
    """Simulated nearby buses with ETA + crowd (feeds the Nearby Buses screen)."""
    return _simulate_buses()


@app.get("/recommend", response_model=RecommendationResponse)
def recommend():
    """Basic recommendation logic: compares ETA + crowd, picks the better bus."""
    buses = _simulate_buses()
    best = min(buses, key=_score)
    reason = (
        f"{best.route} is the best choice right now — only {best.eta_min} min away "
        f"with {best.crowd_label.lower()} crowding ({best.crowd_pct}%)."
    )
    return RecommendationResponse(
        buses=buses, recommended_bus_id=best.bus_id, reason=reason
    )
