"""
SmartBus AI backend (75% milestone)
  - Trained ETA + Crowd ML models drive every prediction
  - SQLite database stores routes and prediction history
  - Simulated GPS: buses move along route paths (km grid), sim clock runs 6x real time

Run:  uvicorn main:app --reload --host 0.0.0.0 --port 8000
"""
import json, math, sqlite3, time
from datetime import datetime
from pathlib import Path
from typing import Optional

import joblib
import pandas as pd
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "ml" / "models"
DB_PATH = Path(__file__).resolve().parent / "smartbus.db"
TIME_SCALE = 6  # 1 real second = 6 simulated seconds (so the demo moves visibly)

eta_model = joblib.load(MODELS / "eta_model.joblib")
crowd_model = joblib.load(MODELS / "crowd_model.joblib")
SCHEMA = json.loads((MODELS / "feature_schema.json").read_text())
METRICS = json.loads((MODELS / "metrics.json").read_text())
COLS = SCHEMA["base_features"] + SCHEMA["route_columns"]

HUB = (7.0, 6.0)  # shared stop every route passes through (the user's stop)
ROUTES = {
    "21A": dict(speed=28, cap=50, delay=2.5, color="#2b5df2", pts=[(1, 6), (4, 5), HUB, (10, 8), (13, 7)]),
    "21B": dict(speed=24, cap=50, delay=4.0, color="#e08a12", pts=[(7, .5), (6, 3), HUB, (8, 9), (7, 12)]),
    "21C": dict(speed=32, cap=45, delay=1.0, color="#1f9d55", pts=[(1, 11), (4, 8.5), HUB, (10, 3.5), (13, 1)]),
    "22A": dict(speed=26, cap=60, delay=3.0, color="#8a4fe0", pts=[(1, 1), (4, 3), HUB, (10, 9.5), (13, 12)]),
    "22B": dict(speed=22, cap=40, delay=5.0, color="#d43d3d", pts=[(13, 5), (10, 5.5), HUB, (4, 7), (1, 8)]),
}


def build_loop(pts):
    """Out-and-back closed loop so buses circulate forever."""
    loop = [tuple(map(float, p)) for p in pts] + [tuple(map(float, p)) for p in reversed(pts[:-1])]
    cum = [0.0]
    for a, b in zip(loop, loop[1:] + loop[:1]):
        cum.append(cum[-1] + math.dist(a, b))
    return loop, cum


for r in ROUTES.values():
    r["loop"], r["cum"] = build_loop(r["pts"])
    r["len"] = r["cum"][-1]
    r["hub_s"] = [r["cum"][i] for i, p in enumerate(r["loop"]) if p == HUB]


def point_at(r, s):
    s %= r["len"]
    loop, cum = r["loop"], r["cum"]
    for i in range(len(loop)):
        if cum[i] <= s <= cum[i + 1]:
            a, b = loop[i], loop[(i + 1) % len(loop)]
            t = (s - cum[i]) / max(cum[i + 1] - cum[i], 1e-9)
            return a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t
    return loop[0]


# ---------------- Simulation state ----------------
FLEET = []
for rid, r in ROUTES.items():
    for k in range(2):
        FLEET.append(dict(bus_id=f"{rid}-{k+1}", route=rid, s=r["len"] * k / 2 + 1.0,
                          onboard=int(r["cap"] * 0.3)))
COND = dict(weather=0, hour=None)
_last = dict(t=time.time(), logged=0.0)


def conditions():
    hour = COND["hour"] if COND["hour"] is not None else datetime.now().hour
    wd = datetime.now().weekday() < 5
    peak = int(wd and (8 <= hour <= 10 or 17 <= hour <= 20))
    traffic = min(1.0, (0.7 if peak else 0.25) + 0.1 * COND["weather"])
    return hour, peak, traffic


def advance():
    now = time.time()
    dt, _last["t"] = min(now - _last["t"], 5.0), now
    hour, peak, traffic = conditions()
    import random
    for b in FLEET:
        r = ROUTES[b["route"]]
        spd = max(r["speed"] * (1 - 0.65 * traffic) * (1 - 0.15 * COND["weather"]), 4)
        b["s"] = (b["s"] + spd * TIME_SCALE * dt / 3600.0) % r["len"]
        target = r["cap"] * (0.65 if peak else 0.3)
        b["onboard"] = int(max(0, min(r["cap"] + 10, b["onboard"] + (target - b["onboard"]) * 0.2 + random.randint(-1, 1))))


def dist_to_hub(b):
    r = ROUTES[b["route"]]
    return min((h - b["s"]) % r["len"] for h in r["hub_s"])


def predict(buses):
    hour, peak, traffic = conditions()
    dow = datetime.now().weekday()
    rows = []
    for b in buses:
        r = ROUTES[b["route"]]
        row = dict(distance_km=max(dist_to_hub(b), 0.05), base_speed_kmph=r["speed"], traffic_level=traffic,
                   hour=hour, day_of_week=dow, is_peak_hour=peak, weather=COND["weather"],
                   historical_avg_delay=r["delay"], stop_waiting_count=15 if peak else 6,
                   onboard_count=b["onboard"], bus_capacity=r["cap"])
        for c in SCHEMA["route_columns"]:
            row[c] = int(c == f"route_{b['route']}")
        rows.append(row)
    X = pd.DataFrame(rows)[COLS]
    return eta_model.predict(X), crowd_model.predict(X)


def label(p):
    return "Low" if p < 40 else "Moderate" if p < 70 else "High"


# ---------------- Database ----------------
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS routes(route_id TEXT PRIMARY KEY, base_speed REAL, capacity INT, hist_delay REAL);
    CREATE TABLE IF NOT EXISTS predictions(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, route_id TEXT,
        bus_id TEXT, distance_km REAL, eta_min REAL, crowd_pct REAL, weather INT, hour INT, recommended INT);
    """)
    for rid, r in ROUTES.items():
        con.execute("INSERT OR REPLACE INTO routes VALUES(?,?,?,?)", (rid, r["speed"], r["cap"], r["delay"]))
    con.commit(); con.close()


init_db()
app = FastAPI(title="SmartBus AI", version="0.75.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class Cond(BaseModel):
    weather: Optional[int] = None
    hour: Optional[int] = None  # 0-23 to force e.g. peak hour for the demo; -1 resets to real time


@app.get("/")
def health():
    return {"status": "ok", "models": METRICS, "time_scale": TIME_SCALE}


@app.get("/routes")
def routes():
    return [dict(id=k, color=v["color"], points=[list(p) for p in v["pts"]], hub=list(HUB)) for k, v in ROUTES.items()]


@app.post("/conditions")
def set_conditions(c: Cond):
    if c.weather is not None:
        COND["weather"] = int(c.weather)
    if c.hour is not None:
        COND["hour"] = None if c.hour < 0 else c.hour
    hour, peak, traffic = conditions()
    return dict(weather=COND["weather"], hour=hour, peak=bool(peak), traffic=round(traffic, 2))


@app.get("/recommend")
def recommend():
    advance()
    etas, crowds = predict(FLEET)
    items = []
    for b, e, c in zip(FLEET, etas, crowds):
        x, y = point_at(ROUTES[b["route"]], b["s"])
        c = max(0.0, min(100.0, float(c)))
        items.append(dict(bus_id=b["bus_id"], route=b["route"], eta_min=round(float(e), 1), crowd_pct=round(c, 1),
                          crowd_label=label(c), distance_km=round(dist_to_hub(b), 2), x=round(x, 2), y=round(y, 2)))
    nxt = {}
    for it in items:  # next-arriving bus on each route
        if it["route"] not in nxt or it["distance_km"] < nxt[it["route"]]["distance_km"]:
            nxt[it["route"]] = it
    buses = sorted(nxt.values(), key=lambda i: i["eta_min"])
    best = min(buses, key=lambda i: i["eta_min"] + i["crowd_pct"] / 100 * 4)
    reason = (f"{best['route']} is the best choice right now: {best['eta_min']:.0f} min away "
              f"with {best['crowd_label'].lower()} crowding ({best['crowd_pct']:.0f}%).")
    hour, peak, traffic = conditions()
    if time.time() - _last["logged"] > 10:  # throttle DB writes to every 10s
        _last["logged"] = time.time()
        con = db()
        ts = datetime.now().isoformat(timespec="seconds")
        con.executemany("INSERT INTO predictions(ts,route_id,bus_id,distance_km,eta_min,crowd_pct,weather,hour,recommended)"
                        " VALUES(?,?,?,?,?,?,?,?,?)",
                        [(ts, i["route"], i["bus_id"], i["distance_km"], i["eta_min"], i["crowd_pct"],
                          COND["weather"], hour, int(i["bus_id"] == best["bus_id"])) for i in buses])
        con.commit(); con.close()
    return dict(buses=buses, recommended_bus_id=best["bus_id"], reason=reason,
                fleet=[dict(bus_id=i["bus_id"], route=i["route"], x=i["x"], y=i["y"]) for i in items],
                conditions=dict(weather=COND["weather"], hour=hour, peak=bool(peak), traffic=round(traffic, 2)))


@app.get("/buses")
def buses():
    return recommend()["buses"]


@app.get("/stats")
def stats():
    con = db()
    per = [dict(r) for r in con.execute(
        "SELECT route_id, COUNT(*) n, ROUND(AVG(eta_min),1) avg_eta, ROUND(AVG(crowd_pct),1) avg_crowd,"
        " SUM(recommended) times_recommended FROM predictions GROUP BY route_id ORDER BY route_id")]
    total = con.execute("SELECT COUNT(*) FROM predictions").fetchone()[0]
    recent = [dict(r) for r in con.execute(
        "SELECT ts, route_id, eta_min, crowd_pct, recommended FROM predictions ORDER BY id DESC LIMIT 15")]
    con.close()
    return dict(total_predictions=total, per_route=per, recent=recent)
