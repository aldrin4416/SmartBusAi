import 'dart:async';
import 'package:flutter/material.dart';
import '../models/bus.dart';
import '../services/api_service.dart';

/// Live map: schematic view of the routes with buses moving in real time.
/// Polls the backend every 2 seconds.
class LiveMapScreen extends StatefulWidget {
  final String? focusRoute;
  const LiveMapScreen({super.key, this.focusRoute});

  @override
  State<LiveMapScreen> createState() => _LiveMapScreenState();
}

class _LiveMapScreenState extends State<LiveMapScreen> {
  final _api = ApiService();
  List<RouteInfo> _routes = [];
  Recommendation? _rec;
  Timer? _timer;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      _routes = await _api.fetchRoutes();
      await _tick();
      _timer = Timer.periodic(const Duration(seconds: 2), (_) => _tick());
    } catch (e) {
      setState(() => _error = "Couldn't reach the backend.\n$e");
    }
  }

  Future<void> _tick() async {
    try {
      final r = await _api.fetchRecommendation();
      if (mounted) setState(() { _rec = r; _error = null; });
    } catch (e) {
      if (mounted) setState(() => _error = "$e");
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _toggle({int? weather, int? hour}) async {
    await _api.setConditions(weather: weather, hour: hour);
    await _tick();
  }

  @override
  Widget build(BuildContext context) {
    final rec = _rec;
    return Scaffold(
      appBar: AppBar(title: Text(widget.focusRoute == null ? "Live Map" : "Route ${widget.focusRoute}")),
      body: _error != null && rec == null
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_error!, textAlign: TextAlign.center)))
          : rec == null
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Expanded(
                    child: Container(
                      margin: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                      clipBehavior: Clip.antiAlias,
                      child: CustomPaint(
                        size: Size.infinite,
                        painter: _MapPainter(_routes, rec.fleet, widget.focusRoute, rec.recommendedBusId),
                      ),
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                    child: Column(children: [
                      Text(rec.reason, style: const TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 6),
                      Row(children: [
                        const Icon(Icons.water_drop, size: 18),
                        const Text(" Rain"),
                        Switch(value: rec.weather == 1, onChanged: (v) => _toggle(weather: v ? 1 : 0)),
                        const Spacer(),
                        const Icon(Icons.traffic, size: 18),
                        Text(" Peak hour"),
                        Switch(value: rec.peak, onChanged: (v) => _toggle(hour: v ? 18 : 12)),
                      ]),
                    ]),
                  ),
                ]),
    );
  }
}

class _MapPainter extends CustomPainter {
  final List<RouteInfo> routes;
  final List<FleetBus> fleet;
  final String? focus, recommendedId;
  _MapPainter(this.routes, this.fleet, this.focus, this.recommendedId);

  Offset _m(List<double> p, Size s) =>
      Offset(24 + p[0] / 14 * (s.width - 48), 24 + p[1] / 13 * (s.height - 48));

  void _text(Canvas c, String t, Offset o, {double size = 10, Color color = Colors.white}) {
    final tp = TextPainter(
        text: TextSpan(text: t, style: TextStyle(fontSize: size, color: color, fontWeight: FontWeight.bold)),
        textDirection: TextDirection.ltr)
      ..layout();
    tp.paint(c, o - Offset(tp.width / 2, tp.height / 2));
  }

  Color _col(String route) => Color(routes.firstWhere((r) => r.id == route).color);

  @override
  void paint(Canvas canvas, Size size) {
    for (final r in routes) {
      final dim = focus != null && focus != r.id;
      final paint = Paint()
        ..color = Color(r.color).withOpacity(dim ? 0.2 : 0.9)
        ..strokeWidth = dim ? 3 : 5
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round;
      final path = Path();
      for (var i = 0; i < r.points.length; i++) {
        final o = _m(r.points[i], size);
        i == 0 ? path.moveTo(o.dx, o.dy) : path.lineTo(o.dx, o.dy);
      }
      canvas.drawPath(path, paint);
    }
    if (routes.isNotEmpty) {
      final h = _m(routes.first.hub, size);
      canvas.drawCircle(h, 11, Paint()..color = Colors.black87);
      canvas.drawCircle(h, 6, Paint()..color = Colors.white);
      _text(canvas, "Your stop", h + const Offset(0, 22), color: Colors.black87);
    }
    for (final b in fleet) {
      if (focus != null && focus != b.route) continue;
      final o = _m([b.x, b.y], size);
      if (b.busId == recommendedId) {
        canvas.drawCircle(o, 17, Paint()..color = Colors.blueAccent.withOpacity(0.25));
        canvas.drawCircle(o, 17, Paint()..color = Colors.blueAccent..style = PaintingStyle.stroke..strokeWidth = 2);
      }
      canvas.drawCircle(o, 11, Paint()..color = _col(b.route));
      canvas.drawCircle(o, 11, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 2);
      _text(canvas, b.route.substring(0, 3), o, size: 8);
    }
  }

  @override
  bool shouldRepaint(covariant _MapPainter old) => true;
}
