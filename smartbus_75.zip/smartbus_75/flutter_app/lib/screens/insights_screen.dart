import 'package:flutter/material.dart';
import '../services/api_service.dart';

/// Trip insights from the SQLite database (prediction history).
class InsightsScreen extends StatefulWidget {
  const InsightsScreen({super.key});
  @override
  State<InsightsScreen> createState() => _InsightsScreenState();
}

class _InsightsScreenState extends State<InsightsScreen> {
  late Future<Map<String, dynamic>> _future = ApiService().fetchStats();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Trip Insights"), actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: () => setState(() => _future = ApiService().fetchStats())),
      ]),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _future,
        builder: (context, snap) {
          if (snap.hasError) return Center(child: Text("Couldn't load: ${snap.error}"));
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final d = snap.data!;
          final per = (d['per_route'] as List).cast<Map<String, dynamic>>();
          return ListView(padding: const EdgeInsets.all(12), children: [
            Card(child: ListTile(
              leading: const Icon(Icons.storage),
              title: Text("${d['total_predictions']} predictions stored"),
              subtitle: const Text("History saved in the backend database"),
            )),
            ...per.map((r) => Card(child: ListTile(
                  leading: CircleAvatar(child: Text(r['route_id'], style: const TextStyle(fontSize: 11))),
                  title: Text("Avg ETA ${r['avg_eta']} min  |  Avg crowd ${r['avg_crowd']}%"),
                  subtitle: Text("${r['n']} readings, recommended ${r['times_recommended']}x"),
                ))),
          ]);
        },
      ),
    );
  }
}
