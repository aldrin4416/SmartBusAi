class Bus {
  final String busId, route, crowdLabel;
  final int etaMin, crowdPct;
  final double distanceKm;

  Bus.fromJson(Map<String, dynamic> j)
      : busId = j['bus_id'] as String,
        route = j['route'] as String,
        etaMin = (j['eta_min'] as num).round(),
        crowdPct = (j['crowd_pct'] as num).round(),
        crowdLabel = j['crowd_label'] as String,
        distanceKm = ((j['distance_km'] ?? 0) as num).toDouble();
}

class FleetBus {
  final String busId, route;
  final double x, y;
  FleetBus.fromJson(Map<String, dynamic> j)
      : busId = j['bus_id'] as String,
        route = j['route'] as String,
        x = (j['x'] as num).toDouble(),
        y = (j['y'] as num).toDouble();
}

class RouteInfo {
  final String id;
  final int color;
  final List<List<double>> points;
  final List<double> hub;
  RouteInfo.fromJson(Map<String, dynamic> j)
      : id = j['id'] as String,
        color = int.parse((j['color'] as String).substring(1), radix: 16) | 0xFF000000,
        points = (j['points'] as List)
            .map<List<double>>((p) => (p as List).map<double>((v) => (v as num).toDouble()).toList())
            .toList(),
        hub = (j['hub'] as List).map<double>((v) => (v as num).toDouble()).toList();
}

class Recommendation {
  final List<Bus> buses;
  final List<FleetBus> fleet;
  final String recommendedBusId, reason;
  final int weather, hour;
  final bool peak;

  Recommendation.fromJson(Map<String, dynamic> j)
      : buses = (j['buses'] as List).map((b) => Bus.fromJson(b as Map<String, dynamic>)).toList(),
        fleet = ((j['fleet'] ?? []) as List).map((b) => FleetBus.fromJson(b as Map<String, dynamic>)).toList(),
        recommendedBusId = j['recommended_bus_id'] as String,
        reason = j['reason'] as String,
        weather = ((j['conditions']?['weather']) ?? 0) as int,
        hour = ((j['conditions']?['hour']) ?? 0) as int,
        peak = ((j['conditions']?['peak']) ?? false) as bool;
}
