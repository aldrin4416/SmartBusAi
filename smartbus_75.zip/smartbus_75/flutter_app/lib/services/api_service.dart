import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/bus.dart';

/// Android emulator -> laptop: http://10.0.2.2:8000
/// iOS simulator / web / desktop: http://127.0.0.1:8000
/// Physical phone on same Wi-Fi: http://<laptop-ip>:8000
class ApiService {
  static const String baseUrl = "http://10.0.2.2:8000";

  Future<dynamic> _get(String path) async {
    final r = await http.get(Uri.parse("$baseUrl$path"));
    if (r.statusCode != 200) throw Exception("GET $path failed (${r.statusCode})");
    return jsonDecode(r.body);
  }

  Future<Recommendation> fetchRecommendation() async =>
      Recommendation.fromJson(await _get("/recommend"));

  Future<List<Bus>> fetchNearbyBuses() async =>
      (await fetchRecommendation()).buses;

  Future<List<RouteInfo>> fetchRoutes() async =>
      ((await _get("/routes")) as List).map((r) => RouteInfo.fromJson(r)).toList();

  Future<Map<String, dynamic>> fetchStats() async =>
      Map<String, dynamic>.from(await _get("/stats"));

  Future<void> setConditions({int? weather, int? hour}) async {
    await http.post(Uri.parse("$baseUrl/conditions"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"weather": weather, "hour": hour}));
  }
}
