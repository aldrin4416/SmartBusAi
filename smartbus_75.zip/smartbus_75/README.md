# SmartBus AI — 75% build

| Stage | Status |
|---|---|
| Prototype UI, FastAPI backend, recommendation | Done (35%) |
| Dataset + ETA model + Crowd model + validation | Done (`ml/`) |
| ML predictions wired into the app backend | Done (`backend/main.py`) |
| Database (SQLite: routes + prediction history) | Done (`backend/smartbus.db`, auto-created) |
| Live map (simulated GPS, buses moving on routes) | Done (`LiveMapScreen`) |
| Trip Insights screen (reads the database) | Done |
| Push notifications, final polish/deployment | Remaining 25% |

## Run the backend
```bash
cd backend
pip install fastapi uvicorn scikit-learn pandas numpy joblib
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```
Endpoints: `/recommend` (ML ETA + crowd + positions), `/routes`, `/stats` (database),
`POST /conditions` (`{"weather":1,"hour":18}` to force rain / peak hour for the demo).

## Run the app
```bash
cd flutter_app && flutter pub get && flutter run -d chrome
```
Check `lib/services/api_service.dart` -> `baseUrl` (10.0.2.2 for Android emulator, 127.0.0.1 for Chrome/iOS).

## Notes
- The simulated clock runs 6x faster than real time so buses visibly move; ETAs are in simulated minutes.
- The map is schematic (km grid, no map tiles or API key needed). Swap in real GPS later without changing the API.
- To retrain: `python ml/data/generate_dataset.py && python ml/train_models.py`.
